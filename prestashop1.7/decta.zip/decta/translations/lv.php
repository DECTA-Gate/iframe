<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{decta}prestashop>decta_93aca46997aa9cfea797fa6073078fd8'] = 'Pieņemiet maksājumus par saviem produktiem, izmantojot bankas kartes';
$_MODULE['<{decta}prestashop>decta_0f379daaee21894a7c6453950658fe8b'] = 'Vai tiešām vēlaties atinstalēt šo moduli?';
$_MODULE['<{decta}prestashop>decta_a02758d758e8bec77a33d7f392eb3f8a'] = 'Šim modulim nav iestatīta valūta.';
$_MODULE['<{decta}prestashop>decta_819225e8ef9e781e3ac6b0dc0bdc816f'] = 'Nepieciešama publiskā atslēga.';
$_MODULE['<{decta}prestashop>decta_585c9619fa6c5a1040a8552aad5eec6e'] = 'Nepieciešama privātā atslēga.';
$_MODULE['<{decta}prestashop>decta_32d6c06706f9a78b7bb9f3d144b7cb33'] = 'Ir nepieciešams derīguma termiņš.';
$_MODULE['<{decta}prestashop>decta_f881a1bd5ed581d563d30316fc764764'] = 'Derīguma termiņš nedrīkst būt mazāks par 5 minūtēm.';
$_MODULE['<{decta}prestashop>decta_c888438d14855d7d96a2724ee9c306bd'] = 'Iestatījumi ir atjaunināti';
$_MODULE['<{decta}prestashop>decta_02cf064329cf953914ae3b1db3477b86'] = 'Maksājiet ar Visa / Mastercard';
$_MODULE['<{decta}prestashop>decta_b4717f6ab3c2357c13c0c2cd32dfc4ca'] = 'API atslēgas';
$_MODULE['<{decta}prestashop>decta_ed6445336472aef39084720adcf903b9'] = 'Publiskā atslēga';
$_MODULE['<{decta}prestashop>decta_952bf87c967660b7bbd4e1eb08cefc92'] = 'Slepenā atslēga';
$_MODULE['<{decta}prestashop>decta_1a0e4804ef5bb0eba3cfd6e4409082e0'] = ' Maksājuma derīguma termiņš (min)';
$_MODULE['<{decta}prestashop>decta_a8bc0f1c1908e5c0da6668b325bbfad5'] = 'Izmantojiet iframe ';
$_MODULE['<{decta}prestashop>decta_c9cc8cce247e49bae79f15173ce97354'] = 'Saglabāt';
$_MODULE['<{decta}prestashop>payment_02cf064329cf953914ae3b1db3477b86'] = 'Maksājiet ar Visa / Mastercard';
$_MODULE['<{decta}prestashop>decta_intro_92c9bed0097b8e7bc21793217fb39d98'] = 'Šis modulis ļauj pieņemt drošus maksājumus, izmantojot bankas kartes.';
$_MODULE['<{decta}prestashop>payment_return_091c355628c309a12c3e4858c6672582'] = 'Maksājums saņemts, jūsu pasūtījums ir pabeigts.';
$_MODULE['<{decta}prestashop>payment_return_d15feee53d81ea16269e54d4784fa123'] = ' Mēs pamanījām problēmu ar jūsu sūtījumu. Ja Jūs domājat, ka notika kļūda, sazinaties';
$_MODULE['<{decta}prestashop>payment_return_66fcf4c223bbf4c7c886d4784e1f62e4'] = 'ar mūsu klientu atbalsta komandu';
$_MODULE['<{decta}prestashop>payment_dffd756d953b7964bfc4820fbac5d323'] = 'Maksājuma rēķins #maksājumanumurs #';
$_MODULE['<{decta}prestashop>payment_24b23a659df2c32a03b4fad4cf03eebd'] = 'Visa / MasterCard';
$_MODULE['<{decta}prestashop>payment_f95da1c548338c3b25654b98a1b9779f'] = ' Maksājums veiksmīgs';
